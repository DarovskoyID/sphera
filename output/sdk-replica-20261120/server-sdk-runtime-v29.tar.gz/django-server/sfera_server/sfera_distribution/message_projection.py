"""Local SQL is a repairable projection of SDK-signed ciphertext operations."""
from hashlib import sha256
import logging

from django.db import transaction
from django.utils import timezone
from sfera_mesh.storage import canonical



def notify_cipher(scope, frame):
    """Fan out a live ciphertext hint through both app and browser gateways.

    Web clients use the Rust WebSocket gateway, which is not subscribed to
    Channels' Redis group keys. Keep this asynchronous so network fan-out never
    holds up the mesh replica request.
    """
    try:
        from sfera_messages.services import _fanout
        _fanout(f'chat_{scope}', {'type': 'mesh_cipher_update', 'frame': frame}, frame)
    except Exception:
        logging.getLogger(__name__).warning('Mesh live notification unavailable')


def live_cipher_frame(scope, value):
    """Build the minimal ciphertext-only frame used for immediate delivery."""
    from sfera_auth.models import User
    user = User.objects.get(pk=value['sender']['user'])
    avatar = user.avatar.url if user.avatar and hasattr(user.avatar, 'url') else str(user.avatar or '')
    return {
        'type': 'mesh_cipher_direct', 'scope': str(scope), 'id': str(value['id']),
        'author': {'id': str(user.pk), 'username': user.username, 'nickname': user.nickname,
                   'avatar': avatar, 'status': user.status},
        'content': '', 'created_at': timezone.now().isoformat(), 'message_type': 'cipher',
        'payload': value, 'publication_state': 'local', 'attachments': [],
        'reply_to': None, 'is_pinned': False, 'edited': False,
    }


def project(directory,record):
    from .projection import synchronize
    from sfera_messages.models import Message,CipherMessageIdentity,Conversation
    from sfera_messages.encryption import encrypt_text
    from sfera_auth.models import User
    operation=record['body'];body=__import__('json').loads(operation['request']['body'])
    value=body['cipher'];digest=sha256(canonical(value)).hexdigest()
    if not Conversation.objects.filter(pk=value['scope'],cipher_only=True).exists():
        synchronize(directory)
    with transaction.atomic():
        old=CipherMessageIdentity.objects.select_for_update().filter(pk=value['id']).first()
        row=Message.objects.select_for_update().filter(pk=value['id']).first()
        if old and old.digest!=digest:raise ValueError('replicated_message_identity_conflict')
        if row:
            if row.message_type!='cipher' or canonical(row.payload)!=canonical(value):raise ValueError('replicated_message_projection_conflict')
            return
        if old:raise ValueError('replicated_message_deleted')
        conversation=Conversation.objects.get(pk=value['scope'],cipher_only=True)
        author=User.objects.get(pk=value['sender']['user'])
        if not conversation.participants.filter(pk=author.pk).exists():raise ValueError('replicated_message_membership')
        CipherMessageIdentity.objects.create(id=value['id'],digest=digest)
        message=Message(id=value['id'],conversation=conversation,author=author,message_type='cipher',encrypted_content=encrypt_text(''))
        message.payload=value;message.save(force_insert=True)

        from sfera_messages.serializers import MessageSerializer
        frame = {**MessageSerializer(message).data, 'type': 'mesh_cipher_projected', 'scope': str(conversation.pk)}
        transaction.on_commit(lambda: notify_cipher(conversation.pk, frame))
