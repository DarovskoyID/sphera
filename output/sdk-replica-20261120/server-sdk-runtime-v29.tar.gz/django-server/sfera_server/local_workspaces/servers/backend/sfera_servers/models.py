"""Servers (guilds). Tables keep their historical sfera_messages_* names."""
import uuid

from django.conf import settings
from django.db import models, transaction, router

from sfera_messages.encryption import decrypt_text, encrypt_text
from sfera_messages.models import RichPayloadMixin, _attachment_upload_path, MESSAGE_TYPE_CHOICES

class Guild(models.Model):
    """A Discord-like server (guild)."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, db_index=True)
    description = models.TextField(blank=True)
    tag = models.CharField(max_length=8, blank=True, default='', db_index=True)
    tags = models.JSONField(default=list, blank=True)
    icon = models.ImageField(upload_to='guild_icons/', null=True, blank=True)
    banner = models.ImageField(upload_to='guild_banners/', null=True, blank=True)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='owned_guilds')
    created_at = models.DateTimeField(auto_now_add=True)
    invite_code = models.CharField(max_length=16, unique=True, blank=True)
    boost_level = models.PositiveIntegerField(default=0)
    verification_level = models.CharField(max_length=20, default='none')
    default_notifications = models.CharField(max_length=20, default='all')
    explicit_content_filter = models.CharField(max_length=30, default='disabled')
    require_2fa = models.BooleanField(default=False)
    is_discoverable = models.BooleanField(default=True)
    is_personal_channel = models.BooleanField(default=False)
    comments_enabled = models.BooleanField(default=True)
    # Official server featured in Explore ("Sfera от разработчиков").
    is_official = models.BooleanField(default=False, db_index=True)
    # Private personal diary: owner-only, never discoverable, can't be joined.
    is_private = models.BooleanField(default=False)

    class Meta:
        db_table = 'sfera_messages_guild'
        indexes = [
            # Speeds up the explore query: filter by is_discoverable, order by members
            models.Index(fields=['is_discoverable', 'name']),
        ]

    def save(self, *args, **kwargs):
        if not self.invite_code:
            import secrets
            self.invite_code = secrets.token_urlsafe(8)[:8]
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class UserServerLayout(models.Model):
    """Per-user layout of the server bar: ordering + folders. Stored as an opaque
    JSON list of entries so the client owns the shape; the server just persists it
    and syncs it across the user's devices.

    entry = {"kind": "guild", "id": "<uuid>"}
          | {"kind": "folder", "id": "f_x", "name": "...", "color": "#..",
             "items": ["<guild uuid>", ...]}
    """
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='server_layout')
    layout = models.JSONField(default=list, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'sfera_messages_userserverlayout'


class GuildMembership(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ROLE_CHOICES = [('owner', 'Owner'), ('admin', 'Admin'), ('member', 'Member')]
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='memberships')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='guild_memberships')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='member')
    nickname = models.CharField(max_length=50, blank=True)
    joined_at = models.DateTimeField(auto_now_add=True)
    muted_until = models.DateTimeField(null=True, blank=True)
    notifications_muted = models.BooleanField(default=False)

    class Meta:
        db_table = 'sfera_messages_guildmembership'
        unique_together = ('guild', 'user')

    def __str__(self):
        return f'{self.user.username} in {self.guild.name} ({self.role})'


class GuildCategory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='categories')
    name = models.CharField(max_length=100)
    position = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildcategory'
        ordering = ['position', 'created_at']

    def __str__(self):
        return f'{self.name} ({self.guild.name})'


class GuildChannel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    CHANNEL_TYPE_CHOICES = [('text', 'Text'), ('voice', 'Voice')]
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='channels')
    category = models.ForeignKey(GuildCategory, on_delete=models.SET_NULL, null=True, blank=True, related_name='channels')
    name = models.CharField(max_length=100)
    channel_type = models.CharField(max_length=10, choices=CHANNEL_TYPE_CHOICES, default='text')
    cipher_only = models.BooleanField(default=False)
    topic = models.CharField(max_length=1024, blank=True)
    position = models.PositiveIntegerField(default=0)
    user_limit = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildchannel'
        ordering = ['position', 'created_at']

    def __str__(self):
        return f'#{self.name} ({self.guild.name})'


class GuildMessageQuerySet(models.QuerySet):
    def update(self, **values):
        from .cipher_messages import CONTENT
        if (set(CONTENT) | {'pk', 'channel', 'author', 'reply_to'}).intersection(values) and (
                values.get('message_type') == 'cipher' or self.filter(message_type='cipher').exists()):
            raise ValueError('cipher_guild_message_is_immutable')
        from sfera_messages.mesh_publication import enabled
        if enabled() and {'id', 'pk', 'channel', 'channel_id', 'author', 'author_id', 'mesh_write_id'}.intersection(values):
            raise ValueError('mesh_guild_identity_is_immutable')
        if enabled() and {'encrypted_content', 'encrypted_payload', 'message_type', 'live_until', 'reply_to', 'reply_to_id', 'edited', 'tags'}.intersection(values):
            rows = list(self[:513])
            if len(rows) > 512:
                raise ValueError('mesh_content_update_batch_limit')
            if any(hasattr(value, 'resolve_expression') for value in values.values()):
                raise ValueError('mesh_content_update_requires_literal_values')
            with transaction.atomic(using=self.db):
                for row in rows:
                    for key, value in values.items():
                        setattr(row, key, value)
                    row.save(using=self.db, update_fields=list(values))
            return len(rows)
        return super().update(**values)

    def bulk_create(self, objs, **kwargs):
        from sfera_messages.mesh_publication import enabled
        values = list(objs)
        if not enabled() and not any(row.message_type == 'cipher' for row in values):
            return super().bulk_create(values, **kwargs)
        if kwargs.get('ignore_conflicts') or kwargs.get('update_conflicts'):
            raise ValueError('mesh_guild_bulk_conflicts_not_supported')
        if len(values) > 512:
            raise ValueError('mesh_content_update_batch_limit')
        with transaction.atomic(using=self.db):
            for row in values:
                row.save(using=self.db, force_insert=True)
        return values

    def bulk_update(self, objs, fields, **kwargs):
        from .cipher_messages import CONTENT
        values = list(objs)
        if set(CONTENT).intersection(fields) and (any(row.message_type == 'cipher' for row in values) or
                self.filter(pk__in=[row.pk for row in values], message_type='cipher').exists()):
            raise ValueError('cipher_guild_message_is_immutable')
        from sfera_messages.mesh_publication import enabled
        if not enabled():
            return super().bulk_update(values, fields, **kwargs)
        if len(values) > 512 or {'id', 'pk', 'channel', 'channel_id', 'author', 'author_id', 'mesh_write_id'}.intersection(fields):
            raise ValueError('invalid_mesh_guild_bulk_update')
        with transaction.atomic(using=self.db):
            for row in values:
                row.save(using=self.db, update_fields=fields)
        return len(values)


class GuildMessage(RichPayloadMixin):
    message_type = models.CharField(max_length=16, choices=MESSAGE_TYPE_CHOICES + [('cipher', 'Encrypted envelope')], default='text', db_index=True)
    objects = GuildMessageQuerySet.as_manager()
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    channel = models.ForeignKey(GuildChannel, on_delete=models.CASCADE, related_name='messages')
    # Manual tags for search (used by the private diary). Not derived from content.
    tags = models.JSONField(default=list, blank=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='guild_messages')
    encrypted_content = models.TextField()
    reply_to = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL, related_name='replies')
    is_pinned = models.BooleanField(default=False)
    edited = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    mesh_write_id = models.CharField(max_length=64, blank=True, default='')

    def save(self, *args, **kwargs):
        from .cipher_messages import validate_save
        using = kwargs.get('using') or self._state.db or router.db_for_write(type(self), instance=self)
        validate_save(self, using, kwargs.get('update_fields'))
        from sfera_messages.mesh_publication import enabled, capture, require_durable_database
        if not enabled():
            return super().save(*args, **kwargs)
        if args:
            raise ValueError('mesh_guild_save_requires_keyword_arguments')
        using = kwargs.get('using') or self._state.db or router.db_for_write(type(self), instance=self)
        require_durable_database(using)
        kwargs['using'] = using
        with transaction.atomic(using=using):
            old = type(self).objects.using(using).select_for_update().filter(pk=self.pk).values_list('mesh_write_id', flat=True).first()
            result = super().save(**kwargs)
            stored = type(self).objects.using(using).select_related('channel').get(pk=self.pk)
            write = capture(stored, using)
            models.QuerySet.update(type(self).objects.using(using).filter(pk=self.pk), mesh_write_id=write.pk)
            self.mesh_write_id = write.pk
            from sfera_messages.mesh_delivery import enabled as delivery_enabled, enqueue
            if delivery_enabled() and old != write.pk and not getattr(self, '_mesh_backfill', False):
                enqueue(stored, write, using, getattr(self, '_mesh_nonce', ''))
        return result

    class Meta:
        db_table = 'sfera_messages_guildmessage'
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['channel', '-created_at']),
        ]

    @property
    def content(self):
        return decrypt_text(self.encrypted_content)

    @content.setter
    def content(self, value):
        self.encrypted_content = encrypt_text(value)

    def __str__(self):
        return f'{self.author.username} in #{self.channel.name}: {self.content[:40]}'


class GuildAttachmentQuerySet(models.QuerySet):
    def update(self, **values):
        from sfera_messages.mesh_publication import enabled
        if not enabled():
            return super().update(**values)
        if any(hasattr(value, 'resolve_expression') for value in values.values()):
            raise ValueError('mesh_attachment_expression_update_unsupported')
        with transaction.atomic(using=self.db):
            rows = list(self.values_list('pk', 'message_id')[:65])
            if len(rows) > 64:
                raise ValueError('mesh_attachment_update_batch_limit')
            result = super().update(**values)
            affected = {row[1] for row in rows if row[1] is not None}
            affected.update(GuildAttachment.objects.using(self.db).filter(pk__in=[row[0] for row in rows]).exclude(message_id=None).values_list('message_id', flat=True))
            for message in GuildMessage.objects.using(self.db).filter(pk__in=affected):
                message.save(using=self.db)
            return result

    def bulk_create(self, objs, **kwargs):
        from sfera_messages.mesh_publication import enabled
        if not enabled():
            return super().bulk_create(objs, **kwargs)
        if kwargs.get('ignore_conflicts') or kwargs.get('update_conflicts'):
            raise ValueError('mesh_attachment_bulk_conflicts_not_supported')
        values = list(objs)
        if len(values) > 64:
            raise ValueError('mesh_attachment_update_batch_limit')
        with transaction.atomic(using=self.db):
            for value in values:
                value.save(using=self.db, force_insert=True)
        return values


class GuildAttachment(models.Model):
    objects = GuildAttachmentQuerySet.as_manager()
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    channel = models.ForeignKey(GuildChannel, on_delete=models.CASCADE, related_name='attachments')
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    message = models.ForeignKey(GuildMessage, on_delete=models.SET_NULL, null=True, blank=True, related_name='attachments')
    file = models.FileField(upload_to=_attachment_upload_path)
    original_filename = models.CharField(max_length=255)
    content_type = models.CharField(max_length=100)
    file_size = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        from sfera_messages.mesh_publication import enabled, require_durable_database
        if not enabled():
            return super().save(*args, **kwargs)
        if args:
            raise ValueError('mesh_attachment_save_requires_keyword_arguments')
        using = kwargs.get('using') or self._state.db or router.db_for_write(type(self), instance=self)
        require_durable_database(using)
        with transaction.atomic(using=using):
            old = type(self).objects.using(using).filter(pk=self.pk).values_list('message_id', flat=True).first()
            result = super().save(using=using, **{key: value for key, value in kwargs.items() if key != 'using'})
            current = type(self).objects.using(using).filter(pk=self.pk).values_list('message_id', flat=True).first()
            for message in GuildMessage.objects.using(using).filter(pk__in={pk for pk in (old, current) if pk}):
                message.save(using=using)
            return result

    def __str__(self):
        return f'{self.original_filename} ({self.file_size} bytes)'

    class Meta:
        db_table = 'sfera_messages_guildattachment'


class GuildScheduledMessage(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    channel = models.ForeignKey(GuildChannel, on_delete=models.CASCADE, related_name='scheduled_messages')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    encrypted_content = models.TextField()
    send_at = models.DateTimeField(db_index=True)
    reply_to = models.ForeignKey(GuildMessage, null=True, blank=True, on_delete=models.SET_NULL)
    attachment_ids = models.JSONField(default=list)
    is_sent = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def content(self):
        return decrypt_text(self.encrypted_content)

    def __str__(self):
        return f'Guild scheduled by {self.author.username} at {self.send_at}'

    class Meta:
        db_table = 'sfera_messages_guildscheduledmessage'


class GuildEmoji(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='emojis')
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='guild_emojis/')
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildemoji'
        unique_together = ('guild', 'name')

    def __str__(self):
        return f':{self.name}: ({self.guild.name})'


class GuildSticker(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='stickers')
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=200, blank=True)
    image = models.ImageField(upload_to='guild_stickers/')
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.name} ({self.guild.name})'

    class Meta:
        db_table = 'sfera_messages_guildsticker'


class GuildSound(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='sounds')
    name = models.CharField(max_length=50)
    file = models.FileField(upload_to='guild_sounds/')
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.name} ({self.guild.name})'

    class Meta:
        db_table = 'sfera_messages_guildsound'


class GuildRole(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='custom_roles')
    name = models.CharField(max_length=50)
    color = models.CharField(max_length=7, default='#99aab5')
    permissions = models.JSONField(default=list)
    position = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildrole'
        ordering = ['position', 'created_at']

    def __str__(self):
        return f'{self.name} ({self.guild.name})'


class GuildMemberRole(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    membership = models.ForeignKey(GuildMembership, on_delete=models.CASCADE, related_name='custom_role_assignments')
    role = models.ForeignKey(GuildRole, on_delete=models.CASCADE, related_name='member_assignments')

    class Meta:
        db_table = 'sfera_messages_guildmemberrole'
        unique_together = ('membership', 'role')


class GuildInvite(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='invites')
    creator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='+')
    code = models.CharField(max_length=16, unique=True, blank=True)
    max_uses = models.PositiveIntegerField(null=True, blank=True)
    uses = models.PositiveIntegerField(default=0)
    expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.code:
            import secrets
            self.code = secrets.token_urlsafe(8)[:8]
        super().save(*args, **kwargs)

    def __str__(self):
        return f'Invite {self.code} for {self.guild.name}'

    class Meta:
        db_table = 'sfera_messages_guildinvite'


class GuildAuditLog(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    guild = models.ForeignKey(Guild, on_delete=models.CASCADE, related_name='audit_logs')
    action = models.CharField(max_length=50)
    actor_id = models.CharField(max_length=40)
    actor_username = models.CharField(max_length=150)
    target_id = models.CharField(max_length=40, blank=True)
    target_username = models.CharField(max_length=150, blank=True)
    details = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildauditlog'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.action} by {self.actor_username} in {self.guild.name}'


class GuildMessageReaction(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    message = models.ForeignKey(GuildMessage, on_delete=models.CASCADE, related_name='reactions')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    emoji = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildmessagereaction'
        unique_together = ('message', 'user', 'emoji')


class GuildMessageView(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    message = models.ForeignKey(GuildMessage, on_delete=models.CASCADE, related_name='views')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildmessageview'
        unique_together = ('message', 'user')


class GuildPollVote(models.Model):
    """One row per (voter, chosen option). Polls live in guild channels only."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    message = models.ForeignKey(GuildMessage, on_delete=models.CASCADE, related_name='poll_votes')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    option_id = models.CharField(max_length=32)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildpollvote'
        unique_together = ('message', 'user', 'option_id')


class GuildTodoCheck(models.Model):
    """A ticked checklist item in a guild channel. Same shared-state semantics as
    TodoCheck."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    message = models.ForeignKey(GuildMessage, on_delete=models.CASCADE, related_name='todo_checks')
    item_id = models.CharField(max_length=32)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'sfera_messages_guildtodocheck'
        unique_together = ('message', 'item_id')


class GuildPostComment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    message = models.ForeignKey(GuildMessage, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    encrypted_content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table = 'sfera_messages_guildpostcomment'
        ordering = ['created_at']

    @property
    def content(self):
        return decrypt_text(self.encrypted_content)

    @content.setter
    def content(self, value):
        self.encrypted_content = encrypt_text(value)


class GuildCipherMessageIdentity(models.Model):
    authorization = models.JSONField(default=dict)
    # Permanent consumed UUID; deliberately survives deletion of a channel/message.
    id = models.UUIDField(primary_key=True)
    digest = models.CharField(max_length=64)
    created_at = models.DateTimeField(auto_now_add=True)
